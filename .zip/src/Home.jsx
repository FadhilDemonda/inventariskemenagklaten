import React, { useState} from 'react';
import { Plus, Edit3, Search } from 'lucide-react';

function Home() {
  const [activeMenu, setActiveMenu] = useState('data');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingItem, setEditingItem] = useState(null);
  
  // Default status dengan warna
  const defaultStatuses = [
    { name: 'Tersedia', color: 'bg-green-100 text-green-800', bgColor: 'green' },
    { name: 'Digunakan', color: 'bg-yellow-100 text-yellow-800', bgColor: 'yellow' },
    { name: 'Rusak', color: 'bg-red-100 text-red-800', bgColor: 'red' }
  ];

  const [customStatuses, setCustomStatuses] = useState([]);
  const [newStatusName, setNewStatusName] = useState('');

  // Data inventaris awal
  const [inventory, setInventory] = useState([
    {
      id: 1,
      name: 'Laptop Dell Inspiron 15',
      status: 'Tersedia',
      availableQty: 8,
      usedQty: 2,
      lastUpdate: '2024-09-15'
    },
    {
      id: 2,
      name: 'Toyota Avanza 2020',
      status: 'Digunakan',
      availableQty: 0,
      usedQty: 2,
      lastUpdate: '2024-09-10'
    },
    {
      id: 3,
      name: 'Honda Vario 150',
      status: 'Tersedia',
      availableQty: 3,
      usedQty: 1,
      lastUpdate: '2024-09-12'
    },
    {
      id: 4,
      name: 'Kabel LAN Cat6',
      status: 'Tersedia',
      availableQty: 50,
      usedQty: 25,
      lastUpdate: '2024-09-08'
    },
    {
      id: 5,
      name: 'Monitor Samsung 24"',
      status: 'Rusak',
      availableQty: 5,
      usedQty: 3,
      lastUpdate: '2024-09-05'
    }
  ]);

  // Form data untuk input barang baru
  const [newItem, setNewItem] = useState({
    name: '',
    status: 'Tersedia',
    availableQty: 0,
    usedQty: 0
  });

  // Gabungkan status default dan custom
  const allStatuses = [...defaultStatuses, ...customStatuses];

  // Fungsi untuk mendapatkan warna status
  const getStatusColor = (status) => {
    const statusObj = allStatuses.find(s => s.name === status);
    return statusObj ? statusObj.color : 'bg-gray-100 text-gray-800';
  };

  // Filter inventory berdasarkan search dan status
  const filteredInventory = inventory.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || item.status === filterStatus;
    return matchesSearch && matchesStatus;
  });

  // Fungsi untuk menambah barang baru
  const handleAddItem = () => {
    if (!newItem.name.trim()) return;

    const newId = Math.max(...inventory.map(item => item.id), 0) + 1;
    const today = new Date().toISOString().split('T')[0];
    
    setInventory([...inventory, {
      ...newItem,
      id: newId,
      lastUpdate: today,
      availableQty: parseInt(newItem.availableQty) || 0,
      usedQty: parseInt(newItem.usedQty) || 0
    }]);

    setNewItem({
      name: '',
      status: 'Tersedia',
      availableQty: 0,
      usedQty: 0
    });
  };

  // Fungsi untuk edit barang
  const handleEditItem = (item) => {
    setEditingItem({ ...item });
    setShowEditModal(true);
  };

  // Fungsi untuk update barang
  const handleUpdateItem = () => {
    const today = new Date().toISOString().split('T')[0];
    setInventory(inventory.map(item => 
      item.id === editingItem.id 
        ? { ...editingItem, lastUpdate: today }
        : item
    ));
    setShowEditModal(false);
    setEditingItem(null);
  };

  // Fungsi untuk menambah status baru
  const handleAddCustomStatus = () => {
    if (!newStatusName.trim()) return;
    
    const newStatus = {
      name: newStatusName,
      color: 'bg-gray-100 text-gray-800',
      bgColor: 'gray'
    };
    
    setCustomStatuses([...customStatuses, newStatus]);
    setNewStatusName('');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navbar */}
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <h1 className="text-xl font-bold text-gray-900">Inventaris Kantor</h1>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                <button
                  onClick={() => setActiveMenu('data')}
                  className={`${activeMenu === 'data' 
                    ? 'border-blue-500 text-gray-900' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm transition-colors duration-200`}
                >
                  Data Barang
                </button>
                <button
                  onClick={() => setActiveMenu('input')}
                  className={`${activeMenu === 'input' 
                    ? 'border-blue-500 text-gray-900' 
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  } whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm transition-colors duration-200`}
                >
                  Input Barang
                </button>
              </div>
            </div>
          </div>
        </div>
      </nav>

      {/* Content */}
      <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        {activeMenu === 'data' ? (
          <div className="px-4 py-6 sm:px-0">
            <div className="bg-white shadow rounded-lg">
              <div className="px-4 py-5 sm:p-6">
                <div className="sm:flex sm:items-center sm:justify-between mb-6">
                  <div>
                    <h3 className="text-lg leading-6 font-medium text-gray-900">
                      Daftar Inventaris Kantor
                    </h3>
                    <p className="mt-1 text-sm text-gray-500">
                      Kelola dan pantau status barang kantor
                    </p>
                  </div>
                </div>

                {/* Search and Filter */}
                <div className="mb-4 flex flex-col sm:flex-row gap-4">
                  <div className="relative flex-1">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <Search className="h-5 w-5 text-gray-400" />
                    </div>
                    <input
                      type="text"
                      placeholder="Cari nama barang..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:placeholder-gray-400 focus:ring-1 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                    />
                  </div>
                  <div className="relative">
                    <select
                      value={filterStatus}
                      onChange={(e) => setFilterStatus(e.target.value)}
                      className="block w-full pl-3 pr-10 py-2 text-base border border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md"
                    >
                      <option value="all">Semua Status</option>
                      {allStatuses.map((status, index) => (
                        <option key={index} value={status.name}>{status.name}</option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Table */}
                <div className="overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                        <tr>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Nama Barang
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Status Barang
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Jumlah Tersedia
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Jumlah Digunakan
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Tanggal Update
                          </th>
                          <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                            Aksi
                          </th>
                        </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                        {filteredInventory.map((item) => (
                          <tr key={item.id} className="hover:bg-gray-50">
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                              {item.name}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap">
                              <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${getStatusColor(item.status)}`}>
                                {item.status}
                              </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {item.availableQty}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                              {item.usedQty}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {new Date(item.lastUpdate).toLocaleDateString('id-ID')}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                              <button
                                onClick={() => handleEditItem(item)}
                                className="text-blue-600 hover:text-blue-900 flex items-center gap-1"
                              >
                                <Edit3 className="h-4 w-4" />
                                Edit
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {filteredInventory.length === 0 && (
                  <div className="text-center py-8">
                    <p className="text-gray-500">Tidak ada barang yang ditemukan</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="px-4 py-6 sm:px-0">
            <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
              {/* Form Input Barang */}
              <div className="bg-white shadow rounded-lg">
                <div className="px-4 py-5 sm:p-6">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                    Tambah Barang Baru
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Nama Barang
                      </label>
                      <input
                        type="text"
                        value={newItem.name}
                        onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm px-3 py-2 border"
                        placeholder="Masukkan nama barang"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Status Barang
                      </label>
                      <select
                        value={newItem.status}
                        onChange={(e) => setNewItem({ ...newItem, status: e.target.value })}
                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm px-3 py-2 border"
                      >
                        {allStatuses.map((status, index) => (
                          <option key={index} value={status.name}>{status.name}</option>
                        ))}
                      </select>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          Jumlah Tersedia
                        </label>
                        <input
                          type="number"
                          value={newItem.availableQty}
                          onChange={(e) => setNewItem({ ...newItem, availableQty: e.target.value })}
                          className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm px-3 py-2 border"
                          min="0"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">
                          Jumlah Digunakan
                        </label>
                        <input
                          type="number"
                          value={newItem.usedQty}
                          onChange={(e) => setNewItem({ ...newItem, usedQty: e.target.value })}
                          className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm px-3 py-2 border"
                          min="0"
                        />
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={handleAddItem}
                      className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Tambah Barang
                    </button>
                  </div>
                </div>
              </div>

              {/* Form Tambah Status Custom */}
              <div className="bg-white shadow rounded-lg">
                <div className="px-4 py-5 sm:p-6">
                  <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
                    Tambah Status Baru
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Nama Status
                      </label>
                      <input
                        type="text"
                        value={newStatusName}
                        onChange={(e) => setNewStatusName(e.target.value)}
                        className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm px-3 py-2 border"
                        placeholder="Masukkan nama status baru"
                      />
                    </div>
                    <button
                      onClick={handleAddCustomStatus}
                      className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 transition-colors duration-200"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Tambah Status
                    </button>
                  </div>

                  {/* Daftar Status */}
                  <div className="mt-6">
                    <h4 className="text-sm font-medium text-gray-700 mb-3">Status yang Tersedia:</h4>
                    <div className="flex flex-wrap gap-2">
                      {allStatuses.map((status, index) => (
                        <span key={index} className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${status.color}`}>
                          {status.name}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Modal Edit */}
      {showEditModal && editingItem && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
            <div className="mt-3">
              <h3 className="text-lg font-medium text-gray-900 mb-4">
                Edit Barang: {editingItem.name}
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">
                    Status Barang
                  </label>
                  <select
                    value={editingItem.status}
                    onChange={(e) => setEditingItem({ ...editingItem, status: e.target.value })}
                    className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm px-3 py-2 border"
                  >
                    {allStatuses.map((status, index) => (
                      <option key={index} value={status.name}>{status.name}</option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Jumlah Tersedia
                    </label>
                    <input
                      type="number"
                      value={editingItem.availableQty}
                      onChange={(e) => setEditingItem({ ...editingItem, availableQty: parseInt(e.target.value) || 0 })}
                      className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm px-3 py-2 border"
                      min="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700">
                      Jumlah Digunakan
                    </label>
                    <input
                      type="number"
                      value={editingItem.usedQty}
                      onChange={(e) => setEditingItem({ ...editingItem, usedQty: parseInt(e.target.value) || 0 })}
                      className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm px-3 py-2 border"
                      min="0"
                    />
                  </div>
                </div>
              </div>
              <div className="flex gap-2 mt-6">
                <button
                  onClick={handleUpdateItem}
                  className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors duration-200"
                >
                  Update
                </button>
                <button
                  onClick={() => {
                    setShowEditModal(false);
                    setEditingItem(null);
                  }}
                  className="flex-1 bg-gray-300 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-400 transition-colors duration-200"
                >
                  Batal
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default Home;